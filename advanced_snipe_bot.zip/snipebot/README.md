# Discord Advanced Snipe Bot

Features:
- Slash commands
- Deleted and edited message sniping
- Per-user/channel history
- Purge commands with auto-clean
- Blacklist system
- Web dashboard (Flask)
- MongoDB or SQLite compatible
