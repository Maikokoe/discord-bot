from discord.ext import commands
from utils.db import is_blacklisted, add_blacklist, remove_blacklist

class Blacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def blacklist(self, ctx, user: commands.UserConverter):
        add_blacklist(user.id)
        await ctx.send(f"{user.name} has been blacklisted.")

    @commands.command()
    async def whitelist(self, ctx, user: commands.UserConverter):
        remove_blacklist(user.id)
        await ctx.send(f"{user.name} has been whitelisted.")

async def setup(bot):
    await bot.add_cog(Blacklist(bot))
