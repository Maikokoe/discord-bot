from discord.ext import commands
import discord
from utils.db import insert_snipe, get_last_snipe

class Snipe(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.snipes = {}

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if not message.author.bot:
            self.snipes[message.channel.id] = (message.content, message.author, message.created_at)

    @commands.command()
    async def snipe(self, ctx):
        snipe = self.snipes.get(ctx.channel.id)
        if not snipe:
            return await ctx.send("Nothing to snipe.")
        content, author, timestamp = snipe
        await ctx.send(f"**{author}** said:
{content}
*{timestamp.strftime('%Y-%m-%d %H:%M:%S')}*")

async def setup(bot):
    await bot.add_cog(Snipe(bot))
