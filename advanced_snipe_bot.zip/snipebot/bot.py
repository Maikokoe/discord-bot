import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TOKEN")

intents = discord.Intents.default()
intents.messages = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

for cog in ["snipe", "purge", "blacklist"]:
    bot.load_extension(f"cogs.{cog}")

@bot.event
async def on_ready():
    print(f"Bot connected as {bot.user}")

bot.run(TOKEN)
