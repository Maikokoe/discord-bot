import os
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI")

client = MongoClient(MONGO_URI)
db = client.snipedb

def insert_snipe(channel_id, content, author):
    db.snipes.insert_one({
        "channel_id": channel_id,
        "content": content,
        "author": author
    })

def get_last_snipe(channel_id):
    return db.snipes.find_one({"channel_id": channel_id}, sort=[('_id', -1)])

def add_blacklist(user_id):
    db.blacklist.insert_one({"user_id": user_id})

def remove_blacklist(user_id):
    db.blacklist.delete_one({"user_id": user_id})

def is_blacklisted(user_id):
    return db.blacklist.find_one({"user_id": user_id}) is not None
